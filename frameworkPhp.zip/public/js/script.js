console.log('Script affiché');
