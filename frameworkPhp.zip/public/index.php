<?php
require '../app/init.php';

$init = new Core;
