</main>

 <footer class="mt-auto text-white-50">
   <p>Cover template for <a href="https://getbootstrap.com/" class="text-white">Bootstrap</a>, by <a href="https://www.linkedin.com/in/nelly-palassy-89531b13b" class="text-white">Nelly.P</a>.</p>
 </footer>
</div>
<script type="text/javascript" src="<?= URLROOT ?>/js/script.js"></script>
</body>
</html>
