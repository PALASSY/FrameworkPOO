<!--Incure le header-->
<?php require APPROOT. '/views/inc/header.php'; ?>


<h1><?= $data['title'] ?></h1>

<!--Incure le header-->
<?php require APPROOT. '/views/inc/footer.php'; ?>
