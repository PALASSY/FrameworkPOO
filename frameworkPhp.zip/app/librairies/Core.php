<?php
/*
*Classe  => noyau de l'iterator_apply
*Créer les Url et charge le controleur de base
*Gérer le format des Url => controllers/method/params
*/
class Core{
  protected $currentController = 'Pages';
  protected $currentMethod = 'index';
  protected $params = [];

  public function __construct(){
    //$this -> getUrl();
    //print_r => permet d'afficher un tableau / echo ne le permet pas
    //print_r($this -> getUrl());
    $url = $this -> getUrl();

    //On recherche si le controller correspondant au prémier paramètre existe[0]=>class
    //Ici pour accéder au fichier Pages.php/Posts.php/... il faut se dire que le système sort du fichier index.php(public) pour diriger ici
    if(file_exists('../app/controllers/'. ucwords($url[0]). '.php')){
      $this -> currentController = ucwords($url[0]);
      unset($url[0]);
    }//Fin du if
    require_once '../app/controllers/'.$this -> currentController. '.php';
    //On instancie
    $this -> currentController = new $this -> currentController;

    //On recherche si le controller correspondant au deuxième paramètre existe[1]=>method
    if(isset($url[1])){
      //On vérifie si le méthode existe
      if(method_exists($this -> currentController, $url[1])){
        //Si on le trouve on met à jour l'attribut $currentMethod
        $this -> currentMethod = $url[1];
        unset($url[1]);
      }
    }
    //echo $this -> currentMethod;

    //On recherche si le controller correspondant au autre(s) paramètres existe[2....]=>method
    // Ici l'attribut $params est un tableau
    // array_values => stocke les parmètres dans un tableau
    $this -> params = $url ? array_values($url) : [];
    //Retourne le tableau
    //call_user_func_array — Appelle une fonction de rappel avec les paramètres rassemblés en tableau
    call_user_func_array([$this -> currentController, $this -> currentMethod], $this -> params);

  }


  //Prendre les paramètres dans Url
  public function getUrl(){
    if(isset($_GET['url'])){
      $url = rtrim($_GET['url'], '/');
      $url = filter_var($url, FILTER_SANITIZE_URL);
      $url = explode('/', $url);
      return $url;
    }
  }
}
